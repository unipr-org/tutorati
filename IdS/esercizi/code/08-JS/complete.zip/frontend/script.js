function appendContent(tag, filename) {
    var content = $.ajax({
        url: filename,
        async: false,
    }).responseText
    $(tag).append(content)
}
$(document).ready(function () {
    appendContent("main", "html/products-table-view.html")
    appendContent("main", "html/reduce-product-view.html")
})
