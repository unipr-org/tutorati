<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");

class StorageGateway extends Gateway
{
    public function handle_request($parts)
    {
        // echo $parts;
        if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
            http_response_code(204);
            exit();
        } else if ($_SERVER["REQUEST_METHOD"] === "GET") {
            if (count($parts) == 2) {
                // storage/products
                if ($parts[1] == "products") {
                    $file_path = "products.json";
                    if (!file_exists($file_path)) {
                        http_response_code(500);
                        echo json_encode(array(
                            "success" => false,
                            "error" => array(
                                "code" => 500,
                                "message" => "File not found"
                            )
                        ));
                        exit();
                    }

                    $data = json_decode(file_get_contents($file_path), true);

                    // Aggiunta di nuovi campi al JSON
                    foreach ($data as &$product) {
                        $product["stock_status"] = $product["quantity"] > 0 ? "In Stock" : "Out of Stock";
                        $product["total_value"] = $product["price-piece"] * $product["quantity"];
                    }

                    echo json_encode(array(
                        "success" => true,
                        "products" => $data
                    ));


                    exit();
                } else {
                    http_response_code(404);
                    echo json_encode(array(
                        "success" => false,
                        "error" => array(
                            "code" => 404,
                            "message" => "Not found"
                        )
                    ));
                    exit();
                }
            } elseif (count($parts) == 3) {
                // storage/products/categories
                if ($parts[1] == "products" && $parts[2] == "categories") {
                    $file_path = "products.json";
                    if (!file_exists($file_path)) {
                        http_response_code(500);
                        echo json_encode(array(
                            "success" => false,
                            "error" => array(
                                "code" => 500,
                                "message" => "File not found"
                            )
                        ));
                        exit();
                    }

                    $data = json_decode(file_get_contents($file_path), true);
                    $categories = array();

                    // Estrae le categorie uniche
                    foreach ($data as $product) {
                        if (!in_array($product["category"], $categories)) {
                            $categories[] = $product["category"];
                        }
                    }

                    echo json_encode(array(
                        "success" => true,
                        "categories" => $categories
                    ));
                    exit();
                } else {
                    http_response_code(404);
                    echo json_encode(array(
                        "success" => false,
                        "error" => array(
                            "code" => 404,
                            "message" => "Not found"
                        )
                    ));
                    exit();
                }
            } else {
                http_response_code(404);
                echo json_encode(array(
                    "success" => false,
                    "error" => array(
                        "code" => 404,
                        "message" => "Not found"
                    )
                ));
                exit();
            }
        }
    }
}
