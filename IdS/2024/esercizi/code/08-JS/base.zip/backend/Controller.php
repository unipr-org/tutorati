<?php

class Controller
{
    private $api = "";
    public function set_api($api)
    {
        $this->api = $api;
    }
    public function handle_request()
    {

        $uri = preg_replace("/^" . preg_quote($this->api, "/") . "/", "", $_SERVER['REQUEST_URI']);
        # [user, login]
        $uri = preg_replace('/\\/$/', "", $uri);

        $parts = explode("/", $uri);

        # /storage
        switch ($parts[0]) {
            case "storage":
                $gateway = new StorageGateway($parts);
                break;
            default:
                http_response_code(404);
                echo json_encode(array(
                    "success" => false,
                    "error" => array(
                        "code" => 404,
                        "message" => "Not found"
                    )
                ));
                exit();
        }
        try {
            $gateway->handle_request($parts);
        } catch (Exception $e) {
            var_dump($e);
            return;
        }
    }
}
